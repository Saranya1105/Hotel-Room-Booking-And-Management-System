package in.zoro.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "room_id")
    private Room room;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    private int stars;
    private String comment;
    private LocalDateTime createdAt = LocalDateTime.now();
	public Long getId() {
		return id;
	}
	public Room getRoom() {
		return room;
	}
	public User getUser() {
		return user;
	}
	public int getStars() {
		return stars;
	}
	public String getComment() {
		return comment;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public void setStars(int stars) {
		this.stars = stars;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

    // getters + setters
    
}
