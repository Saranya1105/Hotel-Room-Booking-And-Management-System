package in.zoro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.zoro.dto.ReviewRequest;
import in.zoro.dto.RoomDetailResponse;
import in.zoro.entity.Booking;
import in.zoro.repository.RevenueRepository;
import in.zoro.service.ReviewService;
import in.zoro.service.UserService;

@RestController
@RequestMapping("/user")
public class UserReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping("/review")
    public String addReview(@RequestBody ReviewRequest request, Authentication auth) {
        reviewService.addReview(auth.getName(), request);
        return "Review added";
    }

    @GetMapping("/room/{roomId}")
    public RoomDetailResponse getRoomDetails(@PathVariable Long roomId) {
        return reviewService.getRoomDetails(roomId);
    }
}
