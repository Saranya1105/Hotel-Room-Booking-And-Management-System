package in.zoro.enums;

public enum BookingStatus {
    BOOKED,
    CANCELLED,
    COMPLETED
}
