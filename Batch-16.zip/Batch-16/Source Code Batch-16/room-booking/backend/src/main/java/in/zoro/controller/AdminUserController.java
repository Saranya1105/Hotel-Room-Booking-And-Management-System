package in.zoro.controller;

import in.zoro.entity.User;
import in.zoro.enums.Role;
import in.zoro.service.AdminUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/users")
@CrossOrigin("*")
public class AdminUserController {

    @Autowired
    private AdminUserService adminUserService;

    @GetMapping
    public List<User> getAllUsers() {
        return adminUserService.getAllUsers();
    }

    @GetMapping("/role/{role}")
    public List<User> getUsersByRole(@PathVariable Role role) {
        return adminUserService.getUsersByRole(role);
    }

    @PutMapping("/{id}/enable")
    public void enableUser(@PathVariable Long id) {
        adminUserService.enableUser(id);
    }

    @PutMapping("/{id}/disable")
    public void disableUser(@PathVariable Long id) {
        adminUserService.disableUser(id);
    }
}
