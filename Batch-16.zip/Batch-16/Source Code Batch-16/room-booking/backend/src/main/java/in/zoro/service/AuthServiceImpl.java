package in.zoro.service;

import in.zoro.dto.AuthResponse;
import in.zoro.dto.LoginRequest;
import in.zoro.dto.RegisterRequest;
import in.zoro.entity.User;
import in.zoro.enums.Role;
import in.zoro.repository.UserRepository;
import in.zoro.security.JwtUtil;
import in.zoro.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder encoder;

    @Override
    public AuthResponse register(RegisterRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        Role role = Role.valueOf(request.getRole().toUpperCase());

        User user = new User(
                request.getName(),
                request.getEmail(),
                encoder.encode(request.getPassword()),
                request.getPhone(),
                role
        );

        userRepository.save(user);

        String token = jwtUtil.generateToken(user.getEmail(), role.name());
        return new AuthResponse(token, role.name(), user.getName());
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        User user = userRepository.findByEmail(request.getEmail()).orElseThrow();
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        return new AuthResponse(token, user.getRole().name(), user.getName());
    }
}
