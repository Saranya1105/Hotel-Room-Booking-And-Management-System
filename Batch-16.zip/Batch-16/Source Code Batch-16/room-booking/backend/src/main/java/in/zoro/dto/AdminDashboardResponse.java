package in.zoro.dto;

public class AdminDashboardResponse {

    private long totalUsers;
    private long totalVendors;
    private double totalRevenue;

    public AdminDashboardResponse() {}

    public AdminDashboardResponse(long totalUsers,
                                  long totalVendors,
                                  double totalRevenue) {
        this.totalUsers = totalUsers;
        this.totalVendors = totalVendors;
        this.totalRevenue = totalRevenue;
    }

    public long getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(long totalUsers) {
        this.totalUsers = totalUsers;
    }

    public long getTotalVendors() {
        return totalVendors;
    }

    public void setTotalVendors(long totalVendors) {
        this.totalVendors = totalVendors;
    }

    public double getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(double totalRevenue) {
        this.totalRevenue = totalRevenue;
    }
}
