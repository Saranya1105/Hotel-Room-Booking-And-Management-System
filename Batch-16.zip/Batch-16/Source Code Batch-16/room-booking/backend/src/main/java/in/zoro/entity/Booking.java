package in.zoro.entity;

import in.zoro.enums.BookingStatus;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "room_id")
    private Room room;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    private LocalDate startDate;
    private LocalDate endDate;

    @Column(name = "rooms_required", nullable = false)
    private int roomsRequired;

    private double totalAmount;

    @Enumerated(EnumType.STRING)
    private BookingStatus status;

    private double coinsUsed;
    private double cashPaid;
    private double vendorShare;
    private double adminShare;

    @Column(nullable = false)
    private double refundAmount = 0;

    private LocalDate cancelledAt;

    // ===== getters & setters =====

    public Long getId() { return id; }
    public Room getRoom() { return room; }
    public User getUser() { return user; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public int getRoomsRequired() { return roomsRequired; }
    public double getTotalAmount() { return totalAmount; }
    public BookingStatus getStatus() { return status; }
    public double getCoinsUsed() { return coinsUsed; }
    public double getCashPaid() { return cashPaid; }
    public double getVendorShare() { return vendorShare; }
    public double getAdminShare() { return adminShare; }
    public double getRefundAmount() { return refundAmount; }
    public LocalDate getCancelledAt() { return cancelledAt; }

    public void setId(Long id) { this.id = id; }
    public void setRoom(Room room) { this.room = room; }
    public void setUser(User user) { this.user = user; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public void setRoomsRequired(int roomsRequired) { this.roomsRequired = roomsRequired; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }
    public void setStatus(BookingStatus status) { this.status = status; }
    public void setCoinsUsed(double coinsUsed) { this.coinsUsed = coinsUsed; }
    public void setCashPaid(double cashPaid) { this.cashPaid = cashPaid; }
    public void setVendorShare(double vendorShare) { this.vendorShare = vendorShare; }
    public void setAdminShare(double adminShare) { this.adminShare = adminShare; }
    public void setRefundAmount(double refundAmount) { this.refundAmount = refundAmount; }
    public void setCancelledAt(LocalDate cancelledAt) { this.cancelledAt = cancelledAt; }
}
