package in.zoro.dto;

public class ReviewRequest {
    private Long roomId;
    private int stars;
    private String comment;

    public Long getRoomId() { return roomId; }
    public int getStars() { return stars; }
    public String getComment() { return comment; }

    public void setRoomId(Long roomId) { this.roomId = roomId; }
    public void setStars(int stars) { this.stars = stars; }
    public void setComment(String comment) { this.comment = comment; }
}
