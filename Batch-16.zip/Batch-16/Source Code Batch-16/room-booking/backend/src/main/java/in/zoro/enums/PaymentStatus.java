package in.zoro.enums;

public enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING
}
