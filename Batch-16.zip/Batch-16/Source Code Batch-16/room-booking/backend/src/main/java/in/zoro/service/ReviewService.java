package in.zoro.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.zoro.dto.ReviewRequest;
import in.zoro.dto.ReviewResponse;
import in.zoro.dto.RoomDetailResponse;
import in.zoro.entity.Review;
import in.zoro.entity.Room;
import in.zoro.entity.User;
import in.zoro.repository.ReviewRepository;
import in.zoro.repository.RoomRepository;
import in.zoro.repository.UserRepository;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private UserRepository userRepository;

    public void addReview(String email, ReviewRequest request) {

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Room room = roomRepository.findById(request.getRoomId())
                .orElseThrow(() -> new RuntimeException("Room not found"));

        if (request.getStars() < 1 || request.getStars() > 5) {
            throw new RuntimeException("Stars must be between 1 and 5");
        }

        // Update rating
        double oldRating = room.getRating();
        int oldCount = room.getRatingCount();
        double newRating = (oldRating * oldCount + request.getStars()) / (oldCount + 1);

        room.setRating(newRating);
        room.setRatingCount(oldCount + 1);

        // Save review
        Review review = new Review();
        review.setRoom(room);
        review.setUser(user);
        review.setStars(request.getStars());
        review.setComment(request.getComment());

        reviewRepository.save(review);
        roomRepository.save(room);
    }

    public RoomDetailResponse getRoomDetails(Long roomId) {

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        List<Review> reviews = reviewRepository.findByRoomId(roomId);

        RoomDetailResponse res = new RoomDetailResponse();
        res.id = room.getId();
        res.roomName = room.getRoomName();
        res.location = room.getLocation();
        res.pricePerDay = room.getPricePerDay();
        res.rating = room.getRating();
        res.imageUrl = room.getImagePath();

        res.reviews = reviews.stream().map(r -> {
            ReviewResponse rr = new ReviewResponse();
            rr.user = r.getUser().getName();
            rr.stars = r.getStars();
            rr.comment = r.getComment();
            rr.createdAt = r.getCreatedAt();
            return rr;
        }).collect(Collectors.toList());

        return res;
    }
}
