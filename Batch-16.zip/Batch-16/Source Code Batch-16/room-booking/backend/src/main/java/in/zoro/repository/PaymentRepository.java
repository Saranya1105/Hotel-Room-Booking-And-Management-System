package in.zoro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import in.zoro.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

}
