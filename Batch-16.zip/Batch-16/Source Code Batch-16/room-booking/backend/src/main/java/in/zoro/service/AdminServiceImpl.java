package in.zoro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.zoro.dto.AdminDashboardResponse;
import in.zoro.enums.BookingStatus;
import in.zoro.enums.Role;
import in.zoro.repository.BookingRepository;
import in.zoro.repository.UserRepository;
import in.zoro.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Override
    public AdminDashboardResponse getDashboardStats() {

        long totalUsers = userRepository.countByRole(Role.USER);
        long totalVendors = userRepository.countByRole(Role.VENDOR);

        // ✅ THIS IS THE LINE YOU ASKED "WHERE?"
        double totalRevenue =
                bookingRepository.getTotalAdminRevenue();

        return new AdminDashboardResponse(
                totalUsers,
                totalVendors,
                totalRevenue
        );
    }
}
