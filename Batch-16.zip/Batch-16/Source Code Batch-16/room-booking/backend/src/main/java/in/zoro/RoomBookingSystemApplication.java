package in.zoro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import in.zoro.entity.User;
import in.zoro.enums.Role;
import in.zoro.repository.UserRepository;

@SpringBootApplication
public class RoomBookingSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(RoomBookingSystemApplication.class, args);
    }

    @Bean
    CommandLineRunner createAdmin(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder
    ) {
        return args -> {

            String adminEmail = "admin@gmail.com";

            if (userRepository.findByEmail(adminEmail).isPresent()) {
                System.out.println("✅ Admin already exists");
                return;
            }

            User admin = new User();
            admin.setName("System Admin");
            admin.setEmail(adminEmail);
            admin.setPassword(passwordEncoder.encode("admin123")); // 🔐 bcrypt
            admin.setRole(Role.ADMIN);
            admin.setActive(true);

            userRepository.save(admin);

            System.out.println("🚀 Admin user created successfully");
        };
    }
}
