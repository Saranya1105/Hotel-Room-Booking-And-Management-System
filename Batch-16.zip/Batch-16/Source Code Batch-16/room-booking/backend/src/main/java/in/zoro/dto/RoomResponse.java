package in.zoro.dto;

public class RoomResponse {

    private Long id;
    private String roomName;
    private String location;
    private double pricePerDay;
    private boolean enabled;
    private String imagePath;
    private double rating;

    // ✅ NEW
    private boolean ac;
    private int availableRooms;

    public RoomResponse(
            Long id,
            String roomName,
            String location,
            double pricePerDay,
            boolean enabled,
            String imagePath,
            double rating,
            boolean ac,
            int availableRooms
    ) {
        this.id = id;
        this.roomName = roomName;
        this.location = location;
        this.pricePerDay = pricePerDay;
        this.enabled = enabled;
        this.imagePath = imagePath;
        this.rating = rating;
        this.ac = ac;
        this.availableRooms = availableRooms;
    }

    public Long getId() { return id; }
    public String getRoomName() { return roomName; }
    public String getLocation() { return location; }
    public double getPricePerDay() { return pricePerDay; }
    public boolean isEnabled() { return enabled; }
    public String getImagePath() { return imagePath; }
    public double getRating() { return rating; }
    public boolean isAc() { return ac; }
    public int getAvailableRooms() { return availableRooms; }
}
