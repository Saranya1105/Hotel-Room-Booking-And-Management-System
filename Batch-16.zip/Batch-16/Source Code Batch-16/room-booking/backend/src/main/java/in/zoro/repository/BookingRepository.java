package in.zoro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.zoro.entity.Booking;
import in.zoro.entity.User;
import in.zoro.enums.BookingStatus;
import in.zoro.entity.Room;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByUser(User user);

    List<Booking> findByRoom(Room room);
    
    List<Booking> findByRoom_Vendor(User vendor);
    
        @Query("SELECT COALESCE(SUM(b.adminShare), 0) FROM Booking b WHERE b.status IN ('BOOKED' , 'CANCELLED')")
        double getTotalAdminRevenue();
        
        @Query("SELECT COALESCE(SUM(b.adminShare), 0) FROM Booking b WHERE b.status = :status")
        double getTotalAdminRevenue(@Param("status") BookingStatus status);






}
