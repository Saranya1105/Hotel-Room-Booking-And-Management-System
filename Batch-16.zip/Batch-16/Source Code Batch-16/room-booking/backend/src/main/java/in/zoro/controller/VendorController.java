package in.zoro.controller;

import in.zoro.dto.RoomRequest;
import in.zoro.dto.RoomResponse;
import in.zoro.dto.VendorProfileResponse;
import in.zoro.entity.Booking;
import in.zoro.service.VendorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/vendor")
@CrossOrigin("*")
public class VendorController {

    @Autowired
    private VendorService vendorService;

    @PostMapping("/rooms")
    public RoomResponse addRoom(@RequestBody RoomRequest request, Authentication auth) {
        return vendorService.addRoom(request, auth.getName());
    }

    @PutMapping("/rooms/{id}")
    public RoomResponse updateRoom(@PathVariable Long id, @RequestBody RoomRequest request, Authentication auth) {
        return vendorService.updateRoom(id, request, auth.getName());
    }

    @PutMapping("/rooms/{id}/enable")
    public RoomResponse enableRoom(@PathVariable Long id, Authentication auth) {
        return vendorService.enableRoom(id, auth.getName());
    }

    @PutMapping("/rooms/{id}/disable")
    public RoomResponse disableRoom(@PathVariable Long id, Authentication auth) {
        return vendorService.disableRoom(id, auth.getName());
    }

    @GetMapping("/rooms")
    public List<RoomResponse> getVendorRooms(Authentication auth) {
        return vendorService.getVendorRooms(auth.getName());
    }
    @GetMapping("/debug")
    public String debug(Authentication auth) {
        System.out.println("SPRING_AUTH = " + auth);
        return (auth == null ? "NO_AUTH" : auth.getAuthorities().toString());
    }
    @PostMapping("/rooms/{roomId}/image")
    public String uploadRoomImage(@PathVariable Long roomId, @RequestParam("file") MultipartFile file, Authentication auth) {
        return vendorService.uploadRoomImage(roomId, file, auth.getName());
    }
    
    @GetMapping("/bookings")
    public List<Booking> getVendorBookings(Authentication auth) {
        return vendorService.getVendorBookings(auth.getName());
    }
    
    @GetMapping("/profile")
    public VendorProfileResponse profile(Authentication auth) {
        return vendorService.getProfile(auth.getName());
    }
    
    @PutMapping("/profile")
    public VendorProfileResponse updateProfile(
            @RequestBody VendorProfileResponse req,
            Authentication auth
    ) {
        return vendorService.updateProfile(auth.getName(), req);
    }


}
