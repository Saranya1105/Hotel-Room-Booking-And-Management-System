package in.zoro.dto;

public class MonthlyGrowthDto {
    private String month;
    private long users;
    private long bookings;
	public String getMonth() {
		return month;
	}
	public long getUsers() {
		return users;
	}
	public long getBookings() {
		return bookings;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public void setUsers(long users) {
		this.users = users;
	}
	public void setBookings(long bookings) {
		this.bookings = bookings;
	}
    
    
}
