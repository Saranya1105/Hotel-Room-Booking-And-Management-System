package in.zoro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import in.zoro.entity.Room;
import in.zoro.entity.User;
import java.util.List;

public interface RoomRepository extends JpaRepository<Room, Long> {

    List<Room> findByVendor(User vendor);

    List<Room> findByLocationContainingIgnoreCase(String location);

    List<Room> findByEnabledTrue();
}
