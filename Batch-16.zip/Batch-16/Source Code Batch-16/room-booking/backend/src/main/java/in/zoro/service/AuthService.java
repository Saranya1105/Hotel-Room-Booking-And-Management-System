package in.zoro.service;

import in.zoro.dto.LoginRequest;
import in.zoro.dto.RegisterRequest;
import in.zoro.dto.AuthResponse;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
}
