package in.zoro.service;

import in.zoro.dto.RoomRequest;
import in.zoro.dto.RoomResponse;
import in.zoro.dto.VendorProfileResponse;
import in.zoro.entity.Room;
import in.zoro.entity.User;
import in.zoro.enums.AcType;
import in.zoro.repository.RoomRepository;
import in.zoro.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;
import in.zoro.entity.Booking;
import in.zoro.repository.BookingRepository;
@Service
public class VendorServiceImpl implements VendorService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private BookingRepository bookingRepository;
  

    // ================= COMMON =================
    private User getVendor(String email) {
        return userRepository.findByEmail(email)
                .filter(u -> u.getRole().name().equals("VENDOR"))
                .orElseThrow(() -> new RuntimeException("Vendor not found or not authorized"));
    }

    // ================= ADD ROOM =================
    @Override
    public RoomResponse addRoom(RoomRequest request, String vendorEmail) {
        User vendor = getVendor(vendorEmail);

        Room room = new Room(
        	    request.getRoomName(),
        	    request.getLocation(),
        	    request.getPricePerDay(),
        	    vendor
        	);

        	room.setAcType(AcType.valueOf(request.getAcType()));
        	room.setAvailableRooms(request.getAvailableRooms());

        	roomRepository.save(room);

        return toResponse(room);

    }	
    
    @Override
    public List<Booking> getVendorBookings(String vendorEmail) {
        User vendor = getVendor(vendorEmail);
        return bookingRepository.findByRoom_Vendor(vendor);
    }

    // ================= UPDATE ROOM =================
    @Override
    public RoomResponse updateRoom(Long roomId, RoomRequest request, String vendorEmail) {
        User vendor = getVendor(vendorEmail);

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        if (!room.getVendor().getId().equals(vendor.getId()))
            throw new RuntimeException("Not your room");

        room.setRoomName(request.getRoomName());
        room.setLocation(request.getLocation());
        room.setPricePerDay(request.getPricePerDay());
        room.setAc(request.isAc());
        room.setAvailableRooms(request.getAvailableRooms());

        roomRepository.save(room);
        return toResponse(room);

    }

    // ================= ENABLE / DISABLE =================
    @Override
    public RoomResponse enableRoom(Long roomId, String vendorEmail) {
        User vendor = getVendor(vendorEmail);

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        if (!room.getVendor().getId().equals(vendor.getId()))
            throw new RuntimeException("Not your room");

        room.setEnabled(true);
        roomRepository.save(room);

        return toResponse(room);
    }
    
    @Override
    public VendorProfileResponse updateProfile(String email, VendorProfileResponse req) {
        User vendor = getVendor(email);

        vendor.setName(req.getName());
        vendor.setPhone(req.getPhone());

        userRepository.save(vendor);
        return getProfile(email);
    }


    @Override
    public RoomResponse disableRoom(Long roomId, String vendorEmail) {
        User vendor = getVendor(vendorEmail);

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        if (!room.getVendor().getId().equals(vendor.getId()))
            throw new RuntimeException("Not your room");

        room.setEnabled(false);
        roomRepository.save(room);

        return toResponse(room);
    }

    // ================= GET VENDOR ROOMS =================
    @Override
    public List<RoomResponse> getVendorRooms(String vendorEmail) {
        User vendor = getVendor(vendorEmail);

        return roomRepository.findByVendor(vendor)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    public VendorProfileResponse getProfile(String email) {
        User vendor = getVendor(email);

        VendorProfileResponse res = new VendorProfileResponse();
        res.setId(vendor.getId());
        res.setName(vendor.getName());
        res.setEmail(vendor.getEmail());
        res.setPhone(vendor.getPhone());
        res.setActive(vendor.isActive());
        res.setRole(vendor.getRole().name());
        return res;
    }


    // ================= IMAGE UPLOAD (FIXED) =================
    @Override
    public String uploadRoomImage(Long roomId, MultipartFile file, String email) {

        User vendor = getVendor(email);

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        if (!room.getVendor().getId().equals(vendor.getId())) {
            throw new RuntimeException("Unauthorized");
        }

        if (file.isEmpty()) {
            throw new RuntimeException("Empty file");
        }

        try {
            // project-root/uploads/vendor/{vendorId}/room/{roomId}
            Path roomDir = Paths.get(
                    System.getProperty("user.dir"),
                    "uploads",
                    "vendor",
                    vendor.getId().toString(),
                    "room",
                    room.getId().toString()
            );

            // create folders if not exist
            Files.createDirectories(roomDir);

            // get extension safely
            String originalName = file.getOriginalFilename();
            String extension = (originalName != null && originalName.contains("."))
                    ? originalName.substring(originalName.lastIndexOf("."))
                    : ".jpg";

            Path imagePath = roomDir.resolve("image" + extension);

            // save image
            Files.copy(
                    file.getInputStream(),
                    imagePath,
                    StandardCopyOption.REPLACE_EXISTING
            );

            // save RELATIVE path in DB
            room.setImagePath(
                    "vendor/" + vendor.getId() +
                    "/room/" + room.getId() +
                    "/image" + extension
            );

            roomRepository.save(room);

            return "Image uploaded successfully";

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to save image: " + e.getMessage());
        }
    }

    // ================= MAPPER =================
    	private RoomResponse toResponse(Room room) {
    	    return new RoomResponse(
    	            room.getId(),
    	            room.getRoomName(),
    	            room.getLocation(),
    	            room.getPricePerDay(),
    	            room.isEnabled(),
    	            room.getImagePath(),
    	            room.getRating(),
    	            room.isAc(),
    	            room.getAvailableRooms()
    	    );
    	}

    }

