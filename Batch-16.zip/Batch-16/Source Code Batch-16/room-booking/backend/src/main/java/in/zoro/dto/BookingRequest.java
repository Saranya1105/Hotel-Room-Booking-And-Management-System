package in.zoro.dto;

import java.time.LocalDate;

public class BookingRequest {

    private Long roomId;
    private LocalDate startDate;
    private LocalDate endDate;
    private int roomsRequired = 1;
    private boolean useCoins;

    

    public boolean isUseCoins() {
		return useCoins;
	}
	public void setUseCoins(boolean useCoins) {
		this.useCoins = useCoins;
	}
	public Long getRoomId() { return roomId; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public int getRoomsRequired() { return roomsRequired; }

    public void setRoomId(Long roomId) { this.roomId = roomId; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public void setRoomsRequired(int roomsRequired) { this.roomsRequired = roomsRequired; }
}
