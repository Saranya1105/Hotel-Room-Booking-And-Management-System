package in.zoro.dto;
public class UserRoomResponse {

    private Long id;
    private String roomName;
    private String location;
    private double pricePerDay;
    private String imagePath;
    private double rating;
    private int availableRooms;
    private String acType;

    public UserRoomResponse(Long id, String roomName, String location,
                            double pricePerDay, String imagePath,
                            double rating, int availableRooms, String acType) {
        this.id = id;
        this.roomName = roomName;
        this.location = location;
        this.pricePerDay = pricePerDay;
        this.imagePath = imagePath;
        this.rating = rating;
        this.availableRooms = availableRooms;
        this.acType = acType;
    }

	public Long getId() {
		return id;
	}

	public String getRoomName() {
		return roomName;
	}

	public String getLocation() {
		return location;
	}

	public double getPricePerDay() {
		return pricePerDay;
	}

	public String getImagePath() {
		return imagePath;
	}

	public double getRating() {
		return rating;
	}

	public int getAvailableRooms() {
		return availableRooms;
	}

	public String getAcType() {
		return acType;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setPricePerDay(double pricePerDay) {
		this.pricePerDay = pricePerDay;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

	public void setAcType(String acType) {
		this.acType = acType;
	}

    // getters only
    
}
