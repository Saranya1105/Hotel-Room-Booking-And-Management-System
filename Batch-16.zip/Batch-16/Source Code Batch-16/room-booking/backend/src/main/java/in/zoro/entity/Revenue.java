package in.zoro.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "revenues")
public class Revenue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long vendorId;
    private double vendorAmount;
    private double adminAmount;
    private LocalDateTime timestamp;

    public Revenue() {}

    public Revenue(Long vendorId, double vendorAmount, double adminAmount, LocalDateTime timestamp) {
        this.vendorId = vendorId;
        this.vendorAmount = vendorAmount;
        this.adminAmount = adminAmount;
        this.timestamp = timestamp;
    }

	public Long getId() {
		return id;
	}

	public Long getVendorId() {
		return vendorId;
	}

	public double getVendorAmount() {
		return vendorAmount;
	}

	public double getAdminAmount() {
		return adminAmount;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setVendorId(Long vendorId) {
		this.vendorId = vendorId;
	}

	public void setVendorAmount(double vendorAmount) {
		this.vendorAmount = vendorAmount;
	}

	public void setAdminAmount(double adminAmount) {
		this.adminAmount = adminAmount;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

    // Getters and Setters
    // ...
    
    
}
