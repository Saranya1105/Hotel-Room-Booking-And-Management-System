package in.zoro.enums;

public enum Role {
    ADMIN,
    VENDOR,
    USER
}
