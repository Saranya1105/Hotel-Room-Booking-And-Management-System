package in.zoro.service;

import in.zoro.dto.RoomRequest;
import in.zoro.dto.RoomResponse;
import in.zoro.dto.VendorProfileResponse;
import in.zoro.entity.Booking;

import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface VendorService {
    RoomResponse addRoom(RoomRequest request, String vendorEmail);
    RoomResponse updateRoom(Long roomId, RoomRequest request, String vendorEmail);
    RoomResponse enableRoom(Long roomId, String vendorEmail);
    RoomResponse disableRoom(Long roomId, String vendorEmail);
    List<RoomResponse> getVendorRooms(String vendorEmail);
    List<Booking> getVendorBookings(String vendorEmail);

    VendorProfileResponse getProfile(String vendorEmail);
    VendorProfileResponse updateProfile(String vendorEmail, VendorProfileResponse req);

    
    String uploadRoomImage(Long roomId, MultipartFile file, String vendorEmail);
}
