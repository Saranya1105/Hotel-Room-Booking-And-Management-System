package in.zoro.controller;

import in.zoro.entity.Booking;
import in.zoro.service.AdminBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/bookings")
@CrossOrigin("*")
public class AdminBookingController {

    @Autowired
    private AdminBookingService adminBookingService;

    @GetMapping
    public List<Booking> getAllBookings() {
        return adminBookingService.getAllBookings();
    }
}
