package in.zoro.service;

import in.zoro.entity.Booking;

import java.util.List;

public interface AdminBookingService {

    List<Booking> getAllBookings();

}
