package in.zoro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import in.zoro.entity.Revenue;
import java.util.List;

public interface RevenueRepository extends JpaRepository<Revenue, Long> {

    List<Revenue> findByVendorId(Long vendorId);
}
