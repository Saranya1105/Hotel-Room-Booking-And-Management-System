package in.zoro.entity;

import in.zoro.enums.PaymentStatus;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;

    private double amount;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status;

    private LocalDateTime paymentDateTime;

    public Payment() {
    }

    public Payment(Booking booking, double amount, PaymentStatus status, LocalDateTime paymentDateTime) {
        this.booking = booking;
        this.amount = amount;
        this.status = status;
        this.paymentDateTime = paymentDateTime;
    }

	public Long getId() {
		return id;
	}

	public Booking getBooking() {
		return booking;
	}

	public double getAmount() {
		return amount;
	}

	public PaymentStatus getStatus() {
		return status;
	}

	public LocalDateTime getPaymentDateTime() {
		return paymentDateTime;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public void setStatus(PaymentStatus status) {
		this.status = status;
	}

	public void setPaymentDateTime(LocalDateTime paymentDateTime) {
		this.paymentDateTime = paymentDateTime;
	}

    // Getters and Setters
    
}
