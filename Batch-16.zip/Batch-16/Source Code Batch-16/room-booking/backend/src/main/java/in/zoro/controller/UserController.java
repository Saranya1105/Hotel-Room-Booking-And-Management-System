package in.zoro.controller;

import in.zoro.dto.BookingRequest;
import in.zoro.dto.UserRoomResponse;
import in.zoro.entity.Booking;
import in.zoro.entity.User;
import in.zoro.repository.UserRepository;
import in.zoro.service.UserService;

import org.springframework.security.core.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

    private final UserRepository userRepository;

    @Autowired
    private UserService userService;

    UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/rooms")
    public List<UserRoomResponse> getRooms() {
        return userService.getAllRooms();
    }

    @PostMapping("/book")
    public Long book(@RequestBody BookingRequest request, Authentication auth) {
        return userService.bookRoom(auth.getName(), request);
    }

    @PostMapping("/cancel/{id}")
    public String cancel(@PathVariable Long id, Authentication auth) {
        return userService.cancelBooking(auth.getName(), id);
    }

    // ✅ THE ONLY booking-history endpoint
    @GetMapping("/bookings")
    public List<Booking> myBookings(Authentication auth) {
        return userService.getUserBookings(auth.getName());
    }
    
 // UserController
    @GetMapping("/profile")
    public User profile(Authentication auth) {
        return userRepository.findByEmail(auth.getName())
            .orElseThrow(() -> new RuntimeException("User not found"));
    }

    
    
}
