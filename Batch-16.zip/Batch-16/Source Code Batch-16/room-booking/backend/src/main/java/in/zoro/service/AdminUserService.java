package in.zoro.service;

import in.zoro.entity.User;
import in.zoro.enums.Role;

import java.util.List;

public interface AdminUserService {

    List<User> getAllUsers();

    List<User> getUsersByRole(Role role);

    void enableUser(Long userId);

    void disableUser(Long userId);
}