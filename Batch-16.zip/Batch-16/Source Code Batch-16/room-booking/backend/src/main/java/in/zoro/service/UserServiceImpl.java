package in.zoro.service;

import in.zoro.dto.BookingRequest;
import in.zoro.dto.UserRoomResponse;
import in.zoro.entity.Booking;
import in.zoro.entity.Room;
import in.zoro.entity.User;
import in.zoro.enums.BookingStatus;
import in.zoro.repository.BookingRepository;
import in.zoro.repository.RevenueRepository;
import in.zoro.repository.RoomRepository;
import in.zoro.repository.UserRepository;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final RevenueRepository revenueRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookingRepository bookingRepository;

    UserServiceImpl(RevenueRepository revenueRepository) {
        this.revenueRepository = revenueRepository;
    }

    // ================= AVAILABLE ROOMS =================
    @Override
    public List<UserRoomResponse> getAllRooms() {
        return roomRepository.findByEnabledTrue()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<UserRoomResponse> searchRooms(String query) {
        return roomRepository.findByLocationContainingIgnoreCase(query)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    // ================= BOOK ROOM =================
    @Override
    public Long bookRoom(String email, BookingRequest request) {

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Room room = roomRepository.findById(request.getRoomId())
                .orElseThrow(() -> new RuntimeException("Room not found"));

        int roomsRequired = request.getRoomsRequired();
        if (roomsRequired <= 0) throw new RuntimeException("Invalid rooms count");

        if (room.getAvailableRooms() < roomsRequired)
            throw new RuntimeException("Not enough rooms available");

        int days = request.getEndDate().compareTo(request.getStartDate());
        if (days <= 0) throw new RuntimeException("Invalid date range");

        double total = days * room.getPricePerDay() * roomsRequired;

        double availableCoins = user.getCoins();
        double coinsUsed;
        double cashPaid;

        if (availableCoins >= total) {
            coinsUsed = total;
            cashPaid = 0;
            user.setCoins(availableCoins - total);
        } else {
            coinsUsed = availableCoins;
            cashPaid = total - availableCoins;
            user.setCoins(0);
        }

        Booking booking = new Booking();
        booking.setRoom(room);
        booking.setUser(user);
        booking.setStartDate(request.getStartDate());
        booking.setEndDate(request.getEndDate());
        booking.setRoomsRequired(roomsRequired);   // ✅ THIS FIXES ERROR
        booking.setTotalAmount(total);
        booking.setStatus(BookingStatus.BOOKED);

        booking.setCoinsUsed(coinsUsed);
        booking.setCashPaid(cashPaid);
        booking.setAdminShare(total * 0.10);
        booking.setVendorShare(total * 0.90);

        bookingRepository.save(booking);

        // reduce room availability
        room.setAvailableRooms(room.getAvailableRooms() - roomsRequired);
        roomRepository.save(room);

        userRepository.save(user);

        return booking.getId();
    }

    // ================= CANCEL BOOKING =================
    @Override
    public String cancelBooking(String email, Long bookingId) {

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if (!booking.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Unauthorized cancellation");
        }

        if (booking.getStatus() != BookingStatus.BOOKED) {
            throw new RuntimeException("Booking already cancelled or completed");
        }

        LocalDate today = LocalDate.now();

        // ⛔ Cannot cancel after check-in
        if (!today.isBefore(booking.getStartDate())) {
            throw new RuntimeException("Cannot cancel after check-in date");
        }

        // 💰 40% refund as COINS
        double refundCoins = booking.getTotalAmount() * 0.40;

        user.setCoins(user.getCoins() + refundCoins);

        booking.setRefundAmount(refundCoins);
        booking.setCancelledAt(today);
        booking.setStatus(BookingStatus.CANCELLED);
        
        booking.setVendorShare(0);


        userRepository.save(user);
        bookingRepository.save(booking);
        
        System.out.println("Logged user id = " + user.getId());
        System.out.println("Booking user id = " + booking.getUser().getId());

        return "Cancelled. 40% refunded as coins: " + refundCoins;
    }

    private UserRoomResponse toResponse(Room room) {
        return new UserRoomResponse(
            room.getId(),
            room.getRoomName(),
            room.getLocation(),
            room.getPricePerDay(),
            room.getImagePath(),
            room.getRating(),
            room.getAvailableRooms(),
            room.getAcType() != null
            ? room.getAcType().name()
            : "NON_AC"

        );
    }
    
    @Override
    public List<Booking> getUserBookings(String email) {

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return bookingRepository.findByUser(user);
    }
    
    @Override
    public List<Booking> getMyBookings(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return bookingRepository.findByUser(user);
    }



}
