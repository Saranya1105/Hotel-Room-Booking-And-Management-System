package in.zoro.enums;

public enum AcType {
    AC,
    NON_AC
}
