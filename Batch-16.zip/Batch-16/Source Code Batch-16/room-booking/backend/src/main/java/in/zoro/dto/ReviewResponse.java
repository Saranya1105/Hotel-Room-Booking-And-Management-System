package in.zoro.dto;

import java.time.LocalDateTime;

public class ReviewResponse {
    public String user;
    public int stars;
    public String comment;
    public LocalDateTime createdAt;
}
