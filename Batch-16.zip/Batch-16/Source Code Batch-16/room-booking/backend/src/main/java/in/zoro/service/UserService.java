package in.zoro.service;

import in.zoro.dto.BookingRequest;
import in.zoro.dto.UserRoomResponse;
import in.zoro.entity.Booking;

import java.util.List;

public interface UserService {

    List<UserRoomResponse> getAllRooms();

    List<UserRoomResponse> searchRooms(String query);

    Long bookRoom(String email, BookingRequest request);

    String cancelBooking(String email, Long bookingId);
    
    List<Booking> getUserBookings(String email);
    
    List<Booking> getMyBookings(String email);

}
