package in.zoro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import in.zoro.entity.User;
import in.zoro.enums.Role;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);
    
    long countByRole(Role role);
    
    List<User> findByRole(Role role);


}
