package in.zoro.service;

import in.zoro.dto.AdminDashboardResponse;

public interface AdminService {
    AdminDashboardResponse getDashboardStats();
}
