package in.zoro.dto;

import java.util.List;

public class RoomDetailResponse {
    public Long id;
    public String roomName;
    public String location;
    public double pricePerDay;
    public String imageUrl;
    public double rating;
    public List<ReviewResponse> reviews;
}
