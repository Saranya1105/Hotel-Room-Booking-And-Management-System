package in.zoro.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "wallets")
public class Wallet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    private double coins;

    public Wallet() {
    }

    public Wallet(User user, double coins) {
        this.user = user;
        this.coins = coins;
    }

	public Long getId() {
		return id;
	}

	public User getUser() {
		return user;
	}

	public double getCoins() {
		return coins;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setCoins(double coins) {
		this.coins = coins;
	}

    // Getters and Setters
    
}
