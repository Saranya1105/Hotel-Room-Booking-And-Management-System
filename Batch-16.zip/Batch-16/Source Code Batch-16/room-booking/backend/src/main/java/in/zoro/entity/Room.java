package in.zoro.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import in.zoro.enums.AcType;

@Entity
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String roomName;
    private String location;
    private double pricePerDay;
    private boolean enabled = true;

    // ✅ NEW
    private boolean ac;
    private int availableRooms;

    @ManyToOne
    @JoinColumn(name = "vendor_id")
    private User vendor;

    private String imagePath;
    private double rating = 3.0;
    private int ratingCount = 0;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AcType acType = AcType.NON_AC;


    public Room() {}

    public Room(String roomName, String location, double pricePerDay, User vendor) {
        this.roomName = roomName;
        this.location = location;
        this.pricePerDay = pricePerDay;
        this.vendor = vendor;
    }

	public Long getId() {
		return id;
	}

	public String getRoomName() {
		return roomName;
	}

	public String getLocation() {
		return location;
	}

	public double getPricePerDay() {
		return pricePerDay;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public boolean isAc() {
		return ac;
	}

	public int getAvailableRooms() {
		return availableRooms;
	}

	public User getVendor() {
		return vendor;
	}

	public String getImagePath() {
		return imagePath;
	}

	public double getRating() {
		return rating;
	}

	public int getRatingCount() {
		return ratingCount;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setPricePerDay(double pricePerDay) {
		this.pricePerDay = pricePerDay;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public void setAc(boolean ac) {
		this.ac = ac;
	}

	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

	public void setVendor(User vendor) {
		this.vendor = vendor;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public void setRatingCount(int ratingCount) {
		this.ratingCount = ratingCount;
	}
	
	public AcType getAcType() {
	    return acType;
	}

	public void setAcType(AcType acType) {
	    this.acType = acType;
	}



    // getters & setters
    
}
