import { useEffect, useState } from "react";
import axios from "axios";
import "./UserRooms.css";

export default function UserRooms() {
  const [rooms, setRooms] = useState([]);
  const [filteredRooms, setFilteredRooms] = useState([]);
  const [search, setSearch] = useState("");
  const [price, setPrice] = useState(10000);
  const [acType, setAcType] = useState("ALL");
  const [ratings, setRatings] = useState([]);

  const [selectedRoom, setSelectedRoom] = useState(null);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [roomsRequired, setRoomsRequired] = useState(1);

  const [coins, setCoins] = useState(0);

  const token = sessionStorage.getItem("token");

  // ================= FETCH =================
  useEffect(() => {
    fetchRooms();
    fetchCoins();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [search, price, acType, ratings, rooms]);

  const fetchRooms = async () => {
    try {
      const res = await axios.get("http://localhost:8080/user/rooms", {
        headers: { Authorization: "Bearer " + token },
      });
      setRooms(res.data);
      setFilteredRooms(res.data);
    } catch (err) {
      console.error("Failed to fetch rooms");
    }
  };

  const fetchCoins = async () => {
    try {
      const res = await axios.get("http://localhost:8080/user/profile", {
        headers: { Authorization: "Bearer " + token },
      });
      setCoins(res.data.coins);
    } catch (err) {
      console.error("Failed to fetch profile");
    }
  };

  // ================= FILTERS =================
  const applyFilters = () => {
    let data = [...rooms];

    if (search) {
      data = data.filter(
        (r) =>
          r.roomName.toLowerCase().includes(search.toLowerCase()) ||
          r.location.toLowerCase().includes(search.toLowerCase())
      );
    }

    data = data.filter((r) => r.pricePerDay <= price);

    if (acType !== "ALL") data = data.filter((r) => r.acType === acType);

    if (ratings.length > 0)
      data = data.filter((r) => ratings.includes(Math.floor(r.rating)));

    setFilteredRooms(data);
  };

  const toggleRating = (r) => {
    setRatings((prev) =>
      prev.includes(r) ? prev.filter((x) => x !== r) : [...prev, r]
    );
  };

  // ================= PRICE CALC =================
  const days =
    startDate && endDate
      ? Math.max(
          0,
          (new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)
        )
      : 0;

  const totalAmount =
    selectedRoom && days ? days * selectedRoom.pricePerDay * roomsRequired : 0;

  const coinsUsed = Math.min(coins, totalAmount);
  const cashToPay = Math.max(0, totalAmount - coins);

  // ================= BOOK =================
  const confirmBooking = async () => {
    if (!startDate || !endDate) return alert("Select dates");
    if (days <= 0) return alert("Invalid date range");

    try {
      const res = await axios.post(
        "http://localhost:8080/user/book",
        {
          roomId: selectedRoom.id,
          startDate,
          endDate,
          roomsRequired,
        },
        { headers: { Authorization: "Bearer " + token } }
      );

      alert("Booking successful! ID: " + res.data);
      fetchRooms();
      fetchCoins();
      setSelectedRoom(null);
      setStartDate("");
      setEndDate("");
      setRoomsRequired(1);
    } catch (err) {
      alert(err.response?.data || "Booking failed");
    }
  };

  return (
    <div className="rooms-page-container">
      {/* LEFT FILTER */}
      <aside className="filter-sidebar">
        <h3>Filters</h3>

        <div className="filter-group">
          <label className="group-label">Max Price: ₹{price}</label>
          <input
            type="range"
            min="500"
            max="10000"
            value={price}
            onChange={(e) => setPrice(+e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label className="group-label">AC Preference</label>
          <div className="options-stack">
            <label><input type="radio" checked={acType === "ALL"} onChange={() => setAcType("ALL")} /> All</label>
            <label><input type="radio" checked={acType === "AC"} onChange={() => setAcType("AC")} /> AC</label>
            <label><input type="radio" checked={acType === "NON_AC"} onChange={() => setAcType("NON_AC")} /> Non-AC</label>
          </div>
        </div>

        <div className="filter-group">
          <label className="group-label">Ratings</label>
          <div className="options-stack">
            {[5, 4, 3, 2, 1].map((r) => (
              <label key={r}>
                <input type="checkbox" checked={ratings.includes(r)} onChange={() => toggleRating(r)} /> {r} ⭐
              </label>
            ))}
          </div>
        </div>
      </aside>

      {/* MAIN */}
      <main className="rooms-main-content">
        <div className="search-bar-wrapper">
          <input
            className="main-search-input"
            placeholder="Search rooms or city..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <div className="coins-box">
            <span>Wallet Balance</span>
            <strong>🪙 {coins.toFixed(1)}</strong>
          </div>
        </div>

        <div className="rooms-grid">
          {filteredRooms.map((room) => (
            <div key={room.id} className="modern-room-card">
              <div className="image-container">
                <img 
                    src={`http://localhost:8080/uploads/${room.imagePath}`} 
                    onError={(e) => (e.target.src = "https://via.placeholder.com/300x200")}
                />
                <span className={`ac-badge ${room.acType === 'AC' ? 'is-ac' : 'is-non-ac'}`}>
                  {room.acType === 'AC' ? '❄️ AC' : '💨 Non-AC'}
                </span>
              </div>

              <div className="card-info">
                <div className="card-header-row">
                  <h3>{room.roomName}</h3>
                  <span className="rating-pill">⭐ {room.rating}</span>
                </div>
                <p className="location-text">📍 {room.location}</p>
                <p className="price-text">₹{room.pricePerDay} <span>/ day</span></p>
                
                <button 
                   className={room.availableRooms === 0 ? "sold-out" : ""}
                   disabled={room.availableRooms === 0} 
                   onClick={() => setSelectedRoom(room)}
                >
                  {room.availableRooms > 0 ? "Book Now" : "Sold Out"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* BOOKING MODAL */}
      {selectedRoom && (
  <div className="modal-overlay">
    <div className="booking-window">
      <div className="window-header">
        <div className="header-info">
          <h2>{selectedRoom.roomName}</h2>
          <span>📍 {selectedRoom.location}</span>
        </div>
        <button className="close-x" onClick={() => setSelectedRoom(null)}>&times;</button>
      </div>

      <div className="window-body">
        <div className="input-grid">
          <div className="input-item">
            <label>Check-in</label>
            <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          </div>
          <div className="input-item">
            <label>Check-out</label>
            <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
          </div>
          <div className="input-item full-width">
            <label>Number of Rooms</label>
            <input
              type="number"
              min="1"
              max={selectedRoom.availableRooms}
              value={roomsRequired}
              onChange={(e) => setRoomsRequired(+e.target.value)}
            />
          </div>
        </div>

        <div className="checkout-summary">
          <h4>Payment Summary</h4>
          <div className="summary-row">
            <p>Stay Duration</p>
            <span>{days} Days</span>
          </div>
          <div className="summary-row">
            <p>Room Total (₹{selectedRoom.pricePerDay} x {roomsRequired})</p>
            <span>₹{totalAmount}</span>
          </div>
          <div className="summary-row discount">
            <p>Coin Discount</p>
            <span>- 🪙 {coinsUsed}</span>
          </div>
          <hr />
          <div className="summary-row final">
            <p>Total Payable</p>
            <span>₹{cashToPay}</span>
          </div>
        </div>
      </div>

      <div className="window-footer">
        <button className="btn-secondary" onClick={() => setSelectedRoom(null)}>Cancel</button>
        <button className="btn-primary" onClick={confirmBooking}>Confirm Booking</button>
      </div>
    </div>
  </div>
)}
    </div>
  );
}