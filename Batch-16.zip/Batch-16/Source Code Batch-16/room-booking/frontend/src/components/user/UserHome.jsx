import React, { useState, useEffect } from "react";
import axios from "axios";
import "./UserHome.css";

const heroImages = [
  "https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&q=80&w=1920",
  "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1920",
  "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&q=80&w=1920"
];

function UserHome() {
  const [currentImg, setCurrentImg] = useState(0);
  const [rooms, setRooms] = useState([]);
  const token = sessionStorage.getItem("token");

  // 1. Hero Image Rotation
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImg((prev) => (prev + 1) % heroImages.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // 2. Fetch Data from Backend
  useEffect(() => {
    const fetchRooms = async () => {
      try {
        const res = await axios.get("http://localhost:8080/user/rooms", {
          headers: { Authorization: "Bearer " + token },
        });
        // We only show rooms with rating >= 4 in the featured section
        setRooms(res.data.filter(r => r.rating >= 4));
      } catch (err) {
        console.error("Failed to fetch rooms", err);
      }
    };
    fetchRooms();
  }, [token]);

  // Helper to render stars
  const renderStars = (rating) => {
    return "⭐".repeat(Math.floor(rating));
  };

  return (
    <div className="home-container">
      {/* HERO SECTION */}
      <div 
        className="hero-section" 
        style={{ backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(${heroImages[currentImg]})` }}
      >
        <div className="hero-content">
          <h1 className="hero-logo-text">Zoram Bookings</h1>
          <h2 className="hero-welcome">Welcome to Your Luxury Stay</h2>
          <p className="hero-slogan">Premium rooms, handpicked for your comfort.</p>
          <button className="hero-btn" onClick={() => window.location.href='/user/rooms'}>Explore All Rooms</button>
        </div>
      </div>

      {/* MOVING FEATURED SECTION */}
      <section className="featured-section">
        <h2 className="section-title">Our Top Rated Rooms</h2>
        <div className="slider-container">
          <div className="slider-track">
            {/* We map twice to create an infinite loop effect */}
            {[...rooms, ...rooms].map((room, index) => (
              <div className="featured-card" key={`${room.id}-${index}`}>
                <div className="card-img-wrapper">
                  <img 
                    src={`http://localhost:8080/uploads/${room.imagePath}`} 
                    alt={room.roomName} 
                    onError={(e) => e.target.src = "https://via.placeholder.com/300x200?text=Room+Image"}
                  />
                  <span className="card-price">₹{room.pricePerDay}</span>
                </div>
                <div className="card-info">
                  <h3>{room.roomName}</h3>
                  <p className="card-loc">{room.location}</p>
                  <div className="card-rating">{renderStars(room.rating)} <span className="rating-num">({room.rating})</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default UserHome;