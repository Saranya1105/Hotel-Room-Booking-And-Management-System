import { useEffect, useState } from "react";
import axios from "axios";
import "./UserHistory.css";

export default function UserHistory() {
  const [bookings, setBookings] = useState([]);
  const token = sessionStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      alert("Please login again");
      return;
    }
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const res = await axios.get("http://localhost:8080/user/bookings", {
        headers: { Authorization: "Bearer " + token },
      });
      setBookings(res.data);
    } catch (err) {
      alert("Failed to load booking history");
    }
  };

  const cancelBooking = async (id) => {
    if (!window.confirm("Are you sure you want to cancel this booking?")) return;
    try {
      const res = await axios.post(`http://localhost:8080/user/cancel/${id}`, {}, {
        headers: { Authorization: "Bearer " + token },
      });
      alert(res.data);
      fetchBookings();
    } catch (err) {
      alert(err.response?.data || "Cancellation failed");
    }
  };

  const downloadReceipt = (b) => {
    const receipt = `
ROOM BOOKING RECEIPT
----------------------------
Booking ID : ${b.id}
Room       : ${b.room.roomName}
Location   : ${b.room.location}
Dates      : ${b.startDate} to ${b.endDate}
Total Paid : ₹${b.totalAmount}
Status     : ${b.status}
----------------------------`;

    const blob = new Blob([receipt], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `receipt_${b.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="history-container">
      <div className="history-header">
        <h1>My Booking History</h1>
        <p>View, manage, and download receipts for your stays.</p>
      </div>

      <div className="table-wrapper">
        <table className="modern-table">
          <thead>
            <tr>
              <th>Room Details</th>
              <th>Location</th>
              <th>Stay Dates</th>
              <th>Days</th>
              <th>Total Amount</th>
              <th>Status</th>
              <th className="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.length === 0 ? (
              <tr>
                <td colSpan="7" className="empty-row">No bookings found in your history.</td>
              </tr>
            ) : (
              bookings.map((b) => {
                const days = Math.max(1, (new Date(b.endDate) - new Date(b.startDate)) / (1000 * 60 * 60 * 24));
                return (
                  <tr key={b.id}>
                    <td className="room-name-cell">{b.room.roomName}</td>
                    <td>{b.room.location}</td>
                    <td className="date-cell">
                      <span>{b.startDate}</span> → <span>{b.endDate}</span>
                    </td>
                    <td>{days}</td>
                    <td className="amount-cell">₹{b.totalAmount}</td>
                    <td>
                      <span className={`status-pill ${b.status.toLowerCase()}`}>
                        {b.status}
                      </span>
                    </td>
                    <td className="actions-cell">
                      {b.status === "BOOKED" ? (
                        <button className="cancel-btn" onClick={() => cancelBooking(b.id)}>
                          Cancel
                        </button>
                      ) : (
                        <button className="cancelled-btn" disabled>Cancelled</button>
                      )}
                      <button className="download-btn" onClick={() => downloadReceipt({ ...b, days })}>
                        Receipt
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}