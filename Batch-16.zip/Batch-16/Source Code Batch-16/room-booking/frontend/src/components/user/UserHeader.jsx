import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "./UserHeader.css";
import logo from "../../assets/images/image.png";

function UserHeader() {
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = () => {
    sessionStorage.clear(); // ✅ matches your JWT storage
    navigate("/login");
  };

  return (
    <header className={`user-header ${scrolled ? "header-scrolled" : ""}`}>
      <div className="logo">
        <Link to="/user" className="logo-link">
          <img
            src={logo}                 // ✅ FIXED
            alt="Zoram Bookings Logo"
            className="logo-img"
          />
        </Link>
      </div>

      <nav className="nav-container">
        <div className="nav-links">
          <Link to="/user" className="nav-item">Home</Link>
          <Link to="/user/rooms" className="nav-item">Available Rooms</Link>
          <Link to="/user/my-bookings" className="nav-item">My Bookings</Link>
        </div>
        <button onClick={handleLogout} className="logout-btn">
          Logout
        </button>
      </nav>
    </header>
  );
}

export default UserHeader;
