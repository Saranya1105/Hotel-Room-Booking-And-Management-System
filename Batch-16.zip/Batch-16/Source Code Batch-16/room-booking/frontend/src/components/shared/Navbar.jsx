import React from 'react';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      {/* Navbar component content */}
    </nav>
  );
};

export default Navbar;
