import { useEffect, useState } from "react";
import axios from "axios";
import "./AdminUsers.css";

const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = sessionStorage.getItem("token");

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await axios.get("http://localhost:8080/admin/users", {
        headers: { Authorization: "Bearer " + token },
      });
      setUsers(res.data);
    } catch (err) {
      console.error("Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="loader-container"><div className="loader"></div></div>;

  return (
    <div className="admin-users-container">
      <div className="admin-users-header">
        <div>
          <h1>User Directory</h1>
          <p>Manage platform access for {users.length} members</p>
        </div>
        
      </div>

      <div className="glass-table-container">
        <table className="admin-modern-table">
          <thead>
            <tr>
              <th>Member</th>
              <th>Email Address</th>
              <th>Role</th>
              <th>Access Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>
                  <div className="user-profile-cell">
                    <div className={`avatar-mini ${u.role.toLowerCase()}`}>
                      {u.name.charAt(0)}
                    </div>
                    <span className="user-name">{u.name}</span>
                  </div>
                </td>
                <td className="user-email">{u.email}</td>
                <td>
                  <span className={`role-badge-outline ${u.role.toLowerCase()}`}>
                    {u.role}
                  </span>
                </td>
                <td>
                  <span className={`status-glow ${u.active ? "active" : "blocked"}`}>
                    {u.active ? "Full Access" : "Restricted"}
                  </span>
                </td>
                <td>
                  <button className="settings-btn">Manage</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminUsers;