import { Routes, Route } from "react-router-dom";
import AdminSidebar from "./AdminSidebar";
import AdminDashboard from "./AdminDashboard";
import AdminUsers from "./AdminUsers";
import AdminBookings from "./AdminBookings";
import "./AdminHome.css";

const AdminHome = () => {
  return (
    <div className="admin-layout">
      <AdminSidebar />

      <div className="admin-main-wrapper">


        <main className="admin-content-area">
          <Routes>
            <Route index element={<AdminDashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="bookings" element={<AdminBookings />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default AdminHome;
