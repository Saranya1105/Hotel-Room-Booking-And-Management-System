import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer
} from "recharts";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const token = sessionStorage.getItem("token");

  const fetchDashboard = async () => {
    try {
      const res = await axios.get("http://localhost:8080/admin/dashboard", {
        headers: { Authorization: "Bearer " + token }
      });
      setStats(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { fetchDashboard(); }, []);

  if (!stats) return (
    <div className="admin-loading-screen">
      <div className="spinner"></div>
      <p>Syncing System Data...</p>
    </div>
  );

  return (
    <div className="admin-dashboard-wrapper">
      <header className="premium-header">
        <div className="header-title">
          <h1>Zoram Control Panel</h1>
          <p className="status-badge"><span className="dot"></span> System Live</p>
        </div>
        <button className="glass-refresh-btn" onClick={fetchDashboard}>
          <span className="icon">🔄</span> Refresh Analytics
        </button>
      </header>

      <div className="stats-container-grid">
        <Stat title="Total Users" value={stats.totalUsers.toLocaleString()} icon="👥" color="blue" />
        <Stat title="Total Vendors" value={stats.totalVendors.toLocaleString()} icon="🏢" color="purple" />
        <Stat title="Gross Revenue" value={`₹${stats.totalRevenue.toLocaleString()}`} icon="💳" color="green" />
        <Stat title="Pending Tasks" value={stats.pendingApprovals} icon="⏳" color="red" pulse={true} />
      </div>

      <div className="dashboard-main-visual">
        <div className="chart-info-side">
          <h3>Growth Analytics</h3>
          <p>Tracking user acquisition vs successful bookings over time.</p>
          <div className="legend-custom">
            <div className="item"><span className="line solid"></span> Users</div>
            <div className="item"><span className="line dashed"></span> Bookings</div>
          </div>
        </div>
        
        <div className="chart-render-side">
          <ResponsiveContainer width="100%" height={350}>
            <AreaChart data={stats.growthData}>
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ff4d4d" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#ff4d4d" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#999', fontSize: 12}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#999', fontSize: 12}} />
              <Tooltip 
                contentStyle={{borderRadius: '15px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.1)'}} 
              />
              <Area type="monotone" dataKey="users" stroke="#ff4d4d" fill="url(#areaGrad)" strokeWidth={4} dot={{ r: 4, fill: '#ff4d4d' }} activeDot={{ r: 6 }} />
              <Area type="monotone" dataKey="bookings" stroke="#1a1a1a" fill="transparent" strokeWidth={2} strokeDasharray="8 5" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

const Stat = ({ title, value, icon, color, pulse }) => (
  <div className={`neumorphic-card ${color}`}>
    <div className={`stat-icon-box ${pulse ? 'pulse-anim' : ''}`}>
      {icon}
    </div>
    <div className="stat-content">
      <span className="stat-label">{title}</span>
      <h2 className="stat-value">{value}</h2>
    </div>
  </div>
);

export default AdminDashboard;