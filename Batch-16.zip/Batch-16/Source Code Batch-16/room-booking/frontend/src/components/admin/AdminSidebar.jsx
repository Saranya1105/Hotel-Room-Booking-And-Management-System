import { NavLink, useNavigate } from "react-router-dom";
import "./AdminSidebar.css";

const AdminSidebar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to logout?")) {
      sessionStorage.clear(); // Clears JWT/Session
      navigate("/login");
    }
  };

  return (
    <aside className="admin-sidebar">
      <div className="admin-sidebar-header">
        <h2>Admin</h2>
        <span className="admin-badge">CONTROL</span>
      </div>

      <nav className="admin-nav">
        <NavLink to="/admin" end className="admin-link">
          📊 Dashboard
        </NavLink>

        <NavLink to="/admin/users" className="admin-link">
          👥 Users
        </NavLink>

        <NavLink to="/admin/bookings" className="admin-link">
          📑 Bookings
        </NavLink>
      </nav>

      {/* Logout Button Section */}
      <div className="admin-sidebar-footer">
        <button onClick={handleLogout} className="admin-logout-btn">
          🚪 Logout
        </button>
      </div>
    </aside>
  );
};

export default AdminSidebar;