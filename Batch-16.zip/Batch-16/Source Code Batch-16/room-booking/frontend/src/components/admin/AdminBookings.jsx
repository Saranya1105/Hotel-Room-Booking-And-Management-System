import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AdminBookings.css';

const AdminBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = sessionStorage.getItem("token");

  useEffect(() => {
    fetchGlobalBookings();
  }, []);

  const fetchGlobalBookings = async () => {
    try {
      const res = await axios.get("http://localhost:8080/admin/bookings", {
        headers: { Authorization: "Bearer " + token }
      });
      setBookings(res.data);
    } catch (err) {
      console.error("Error loading global bookings", err);
    } finally {
      setLoading(false);
    }
  };

  // Calculate quick totals for the header
  const totalCommission = bookings.reduce((sum, b) => sum + (b.adminShare || 0), 0);

  if (loading) return (
    <div className="admin-loading-container">
      <div className="pulsing-circle"></div>
      <p>Fetching Financial Records...</p>
    </div>
  );

  return (
    <div className="admin-bookings-wrapper">
      <div className="admin-page-header">
        <div className="header-text">
          <h1>Transaction Ledger</h1>
          <p>Global oversight of platform revenue and vendor payouts.</p>
        </div>
        <div className="revenue-snapshot">
          <span className="snapshot-label">Platform Profit</span>
          <span className="snapshot-value">₹{totalCommission.toLocaleString()}</span>
        </div>
      </div>

      <div className="glass-table-card">
        <table className="admin-modern-table">
          <thead>
            <tr>
              <th>Property & ID</th>
              <th>Customer Details</th>
              <th>Schedule</th>
              <th>Total Bill</th>
              <th>Admin Cut</th>
              <th>Vendor Payout</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {bookings.length === 0 ? (
              <tr>
                <td colSpan="7" className="empty-table-state">
                  No transaction history available.
                </td>
              </tr>
            ) : (
              bookings.map((b) => (
                <tr key={b.id}>
                  <td>
                    <div className="info-cell-primary">
                      <span className="main-text">{b.room?.roomName || 'Unknown Room'}</span>
                      <span className="sub-text">Room ID: #{b.room?.id || 'N/A'}</span>
                    </div>
                  </td>
                  <td>
                    <div className="info-cell-primary">
                      <span className="main-text">{b.user?.name}</span>
                      <span className="sub-text">{b.user?.email}</span>
                    </div>
                  </td>
                  <td className="date-block">
                    <div className="date-tag">{b.startDate}</div>
                    <div className="date-arrow">↓</div>
                    <div className="date-tag">{b.endDate}</div>
                  </td>
                  <td className="amount-total">₹{b.totalAmount?.toLocaleString()}</td>
                  <td className="amount-admin">+ ₹{b.adminShare?.toLocaleString()}</td>
                  <td className="amount-vendor">₹{b.vendorShare?.toLocaleString()}</td>
                  <td>
                    <span className={`status-pill-modern ${b.status?.toLowerCase()}`}>
                      {b.status}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminBookings;