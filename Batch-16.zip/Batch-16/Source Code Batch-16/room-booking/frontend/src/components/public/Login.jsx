import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import "./Login.css";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await axios.post("http://localhost:8080/auth/login", { email, password });
      console.log("LOGIN RESPONSE:", res.data);

      const { token, role } = res.data;
      sessionStorage.setItem("token", token);
      sessionStorage.setItem("role", role);

      if (role === "USER") navigate("/user");
      else if (role === "VENDOR") navigate("/vendor");
      else if (role === "ADMIN") navigate("/admin");
    } catch (err) {
      setError("Invalid email or password. Please try again.");
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-image-side">
        <h1>Welcome Back</h1>
        <p>Login to manage your bookings and explore premium stays tailored just for you.</p>
      </div>
      <div className="auth-form-side">
        <div className="auth-card">
          <h2>Login</h2>
          <span className="auth-subtitle">Enter your credentials to continue</span>
          
          {error && <div className="error-msg">{error}</div>}

          <form onSubmit={handleLogin}>
            <div className="form-group">
              <input type="email" className="auth-input" placeholder="Email Address" 
                     value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="form-group">
              <input type="password" className="auth-input" placeholder="Password" 
                     value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <button type="submit" className="auth-submit-btn">Login</button>
          </form>

          <p className="auth-switch">
            New user? <Link to="/register">Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;