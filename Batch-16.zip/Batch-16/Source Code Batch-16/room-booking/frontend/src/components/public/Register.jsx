import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import "./Register.css";

function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("USER");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await axios.post("http://localhost:8080/auth/register", { name, email, password, phone, role });
      const { token, role: userRole } = res.data;
      sessionStorage.setItem("token", token);
      sessionStorage.setItem("role", userRole);

      if (userRole === "USER") navigate("/user");
      else if (userRole === "VENDOR") navigate("/vendor");
      else if (userRole === "ADMIN") navigate("/admin");
    } catch (err) {
      setError("Registration failed. Please check your details.");
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-image-side">
        <h1>Join Us</h1>
        <p>Register today to start booking luxury rooms or list your property as a vendor.</p>
      </div>
      <div className="auth-form-side">
        <div className="auth-card">
          <h2>Register</h2>
          <span className="auth-subtitle">Create your account in seconds</span>

          {error && <div className="error-msg">{error}</div>}

          <form onSubmit={handleRegister}>
            <div className="form-group">
              <input className="auth-input" placeholder="Full Name" value={name} 
                     onChange={(e) => setName(e.target.value)} required />
            </div>
            <div className="form-group">
              <input type="email" className="auth-input" placeholder="Email Address" 
                     value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="form-group">
              <input type="password" className="auth-input" placeholder="Password" 
                     value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <div className="form-group">
              <input className="auth-input" placeholder="Phone Number" 
                     value={phone} onChange={(e) => setPhone(e.target.value)} required />
            </div>
            <div className="form-group">
              <select className="auth-select" value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="USER">I am a Traveler</option>
                <option value="VENDOR">I am a Vendor</option>
              </select>
            </div>
            <button type="submit" className="auth-submit-btn">Register</button>
          </form>

          <p className="auth-switch">
            Already have an account? <Link to="/login">Sign In</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Register;