import React from "react";
import { Link } from "react-router-dom";
import "./Home.css";
import logo from "../../assets/images/image.png";
function Home() {
  return (
    <div className="landing-page dark-theme">
      {/* NAVIGATION HEADER */}
      <header className="main-header" style={{
  position: 'absolute',
  top: 0,
  left: 0,
  width: '100%',
  height: '90px',
  display: 'flex',
  alignItems: 'center',
  zIndex: 1000,
  background: 'linear-gradient(to bottom, rgba(0,0,0,0.9) 0%, transparent 100%)'
}}>
  <div className="nav-container" style={{
    width: '90%',
    maxWidth: '1200px',
    margin: '0 auto',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  }}>
    <div className="logo">
      <h1 style={{
        color: '#ffffff',
        fontSize: '1.5rem',
        fontWeight: '900',
        letterSpacing: '2px',
        margin: 0,
        textShadow: '0 0 10px rgba(255,255,255,0.3)'
      }}>ZORAM BOOKINGS</h1>
    </div>

    <nav className="nav-links" style={{
      display: 'flex',
      alignItems: 'center',
      gap: '40px' // This creates the space between Login and Sign Up
    }}>
      <Link to="/login" className="nav-item login-link" style={{
        color: '#ffffff',
        textDecoration: 'none',
        fontWeight: '600',
        fontSize: '0.95rem',
        opacity: 0.8
      }}>Login</Link>
      
      <Link to="/register" className="nav-item register-btn" style={{
        background: '#ff4d4d',
        color: '#ffffff',
        textDecoration: 'none',
        padding: '12px 28px',
        borderRadius: '8px',
        fontWeight: '700',
        fontSize: '0.95rem',
        boxShadow: '0 4px 15px rgba(255, 77, 77, 0.3)'
      }}>Sign Up</Link>
    </nav>
  </div>
</header>

      {/* HERO SECTION */}
      <section className="hero">
        <div className="hero-overlay">
          <div className="hero-content">
            <div className="badge">✨ New: Luxury Suites in Goa</div>
            <h1 className="hero-title">Find Your Next <span>Stay</span></h1>
            <p className="hero-subtitle">
              Experience the pinnacle of luxury. Trusted by travelers who demand the best in comfort and style.
            </p>
            <div className="hero-btns">
              <Link to="/login" className="btn-primary">Get Started</Link>
              <Link to="/register" className="btn-secondary">Join Now</Link>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES SECTION */}
      <section className="features-container">
        <h2 className="section-heading">Why Choose RoomStay?</h2>
        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">🏨</div>
            <h3>Luxury Rooms</h3>
            <p>Handpicked premium rooms with top-tier amenities and verified ratings.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">⚡</div>
            <h3>Instant Booking</h3>
            <p>Secure your favorites in seconds with our lightning-fast booking engine.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🪙</div>
            <h3>Digital Wallet</h3>
            <p>Instant refunds and loyalty rewards credited directly to your account.</p>
          </div>
        </div>
      </section>

      {/* FOOTER CTA */}
      <section className="cta-bottom">
        <div className="cta-card">
          <h2>Ready to explore the world?</h2>
          <p>Join over 50,000+ travelers today.</p>
          <Link to="/register" className="btn-primary">Create Your Account</Link>
        </div>
      </section>
    </div>
  );
}

export default Home;