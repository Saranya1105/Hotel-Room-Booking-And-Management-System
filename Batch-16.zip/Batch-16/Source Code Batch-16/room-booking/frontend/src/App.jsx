import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Home from "./components/public/Home";
import Login from "./components/public/Login";
import Register from "./components/public/Register";

import VendorDashboard from "./components/vendor/VendorDashboard";

import UserLayout from "./components/user/UserLayout";
import UserHome from "./components/user/UserHome";
import UserRooms from "./components/user/UserRooms";
import UserHistory from "./components/user/UserHistory";
import AdminHome from "./components/admin/AdminHome";

function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* PUBLIC */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* VENDOR */}
        <Route path="/vendor/*" element={<VendorDashboard />} />

        {/* USER */}
        <Route path="/user" element={<UserLayout />}>
          <Route index element={<UserHome />} />
          <Route path="rooms" element={<UserRooms />} />
          <Route path="my-bookings" element={<UserHistory />} />
        </Route>

        <Route path="/admin/*" element={<AdminHome />} />


        {/* FALLBACK */}
        <Route path="*" element={<Navigate to="/" />} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
